<template>
  <v-col cols="12" sm="12" md="1" class="pt-0 pb-0">
    <slot/>
  </v-col>
</template>

<script>
  export default {
    name: "Col1",
  }
</script>
