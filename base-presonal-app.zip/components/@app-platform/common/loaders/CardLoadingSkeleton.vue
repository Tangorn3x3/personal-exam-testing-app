<script>
export default {
  name: "CardLoadingSkeleton"
}
</script>

<template>
  <v-skeleton-loader
      class="mx-auto"
      type="card"
  ></v-skeleton-loader>
</template>

<style scoped>

</style>