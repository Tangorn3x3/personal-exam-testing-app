<template>
  <login-page-component/>
</template>

<script>

import LoginPageComponent from "@/@app-platform/auth/LoginPageComponent.vue";

export default {
  components: {LoginPageComponent},
  layout: 'inspire',
}
</script>

<style scoped>

</style>
