<template>
  <v-container>
    <v-row>

      <test-platform-fetch/>

    </v-row>

  </v-container>
</template>

<script>

import TestPlatformFetch from "@/components/TestPlatformFetch.vue";

export default {
  components: { TestPlatformFetch},
  data() {
    return {

    }
  },
  computed: {

  },
  mounted() {

  },
  methods: {

  }
}
</script>

<style lang="scss">

</style>
